import { useState, useEffect } from 'react'

export default function AuthScreen({ onLogin }) {
  const [mode, setMode] = useState('login')
  const [form, setForm] = useState({ username: '', password: '' })
  const [err, setErr] = useState('')
  const [users, setUsers] = useState({})

  useEffect(() => {
    try {
      const r = localStorage.getItem('sdv_users')
      if (r) setUsers(JSON.parse(r))
    } catch {}
  }, [])

  const handle = () => {
    setErr('')
    const { username, password } = form
    if (!username.trim() || !password.trim()) { setErr('Completá todos los campos.'); return }
    if (mode === 'register') {
      if (users[username]) { setErr(`El nombre "${username}" ya está en uso. Agregale un número o usá otro nombre.`); return }
      const u = { username, password, album: [], cambios: [] }
      const nu = { ...users, [username]: u }
      localStorage.setItem('sdv_users', JSON.stringify(nu))
      localStorage.setItem('sdv_session', username)
      onLogin(username, nu)
    } else {
      if (!users[username] || users[username].password !== password) { setErr('Usuario o contraseña incorrectos.'); return }
      localStorage.setItem('sdv_session', username)
      onLogin(username, users)
    }
  }

  return (
    <div className="auth-wrap">
      <div className="auth-logo">🐾 Soplo de Vida</div>
      <div className="auth-sub">Álbum de figuritas virtual del refugio</div>
      <div className="auth-card">
        <div className="auth-title">{mode === 'login' ? 'Iniciar sesión' : 'Crear cuenta'}</div>
        <div className="auth-toggle">
          {mode === 'login'
            ? <>¿No tenés cuenta? <span onClick={() => { setMode('register'); setErr('') }}>Registrate</span></>
            : <>¿Ya tenés cuenta? <span onClick={() => { setMode('login'); setErr('') }}>Iniciá sesión</span></>}
        </div>
        {err && <div className="err">{err}</div>}
        <div className="igrp">
          <label className="ilbl">Nombre de usuario</label>
          <input className="ifld" placeholder="Tu nombre" value={form.username}
            onChange={e => setForm({ ...form, username: e.target.value })}
            onKeyDown={e => e.key === 'Enter' && handle()} />
        </div>
        <div className="igrp">
          <label className="ilbl">Contraseña</label>
          <input className="ifld" type="password" placeholder="Tu contraseña" value={form.password}
            onChange={e => setForm({ ...form, password: e.target.value })}
            onKeyDown={e => e.key === 'Enter' && handle()} />
        </div>
        <button className="btn-pri" onClick={handle}>
          {mode === 'login' ? 'Entrar al álbum' : 'Crear mi álbum'} 🐾
        </button>
      </div>
    </div>
  )
}
