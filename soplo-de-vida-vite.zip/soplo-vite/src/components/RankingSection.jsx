import { FIGURITAS_DATA, getPct } from '../data/figuritas'

export default function RankingSection({ allUsers }) {
  const sorted = [...allUsers]
    .map(u => ({ username: u.username, owned: (u.album || []).length, pct: getPct((u.album || []).length, FIGURITAS_DATA.length) }))
    .sort((a, b) => b.pct - a.pct)

  const medals = ['🥇', '🥈', '🥉']
  const pclass = ['gold', 'silver', 'bronze']

  return (
    <div>
      <h1 className="sec-title">Ranking</h1>
      <p className="sec-sub">¿Quién completa el álbum primero? 🏆</p>
      {sorted.length === 0 ? (
        <div className="empty"><div className="eemoji">🏆</div><p>Aún no hay coleccionistas.</p></div>
      ) : sorted.map((u, i) => (
        <div key={u.username} className="rank-card">
          <div className={`rpos ${pclass[i] || ''}`}>{medals[i] || i + 1}</div>
          <div className="rinfo">
            <div className="rname">@{u.username}</div>
            <div className="rpct">{u.owned} figuritas · {u.pct}% completado</div>
          </div>
          <div><div className="rbar-w"><div className="rbar-f" style={{ width: `${u.pct}%` }} /></div></div>
        </div>
      ))}
    </div>
  )
}
