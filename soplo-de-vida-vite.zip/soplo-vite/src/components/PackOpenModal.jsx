import { useState } from 'react'
import { FIGURITAS_DATA, estadoClass, PACK_SIZES } from '../data/figuritas'
import { FOTOS } from '../data/fotos'

const catBg = (cat) => {
  if (cat === 'soplitos_pro') return 'linear-gradient(160deg,#FFFBE6,#FFF3B0)'
  if (cat === 'angelitos')    return 'linear-gradient(160deg,#F0F3F8,#E2E8F4)'
  return 'linear-gradient(160deg,#F3EEFF,#E8DFFA)'
}
const catBorder = (cat) => {
  if (cat === 'soplitos_pro') return '#F5C842'
  if (cat === 'angelitos')    return '#C0C8D8'
  return '#C9B8E8'
}
const catLabel = (cat) => {
  if (cat === 'soplitos_pro') return '⭐ Soplito Pro'
  if (cat === 'angelitos')    return '🕊️ Angelito'
  return '🐾 Soplito'
}

export default function PackOpenModal({ pack, onClose }) {
  const [phase, setPhase] = useState('intro')
  const [current, setCurrent] = useState(0)
  const [flipped, setFlipped] = useState([])

  const [drawn] = useState(() => {
    const shuffled = [...FIGURITAS_DATA].sort(() => Math.random() - 0.5)
    return shuffled.slice(0, pack.cantidad)
  })

  const startOpening = () => {
    setPhase('opening')
    setTimeout(() => { setPhase('reveal'); setCurrent(0) }, 1400)
  }

  const flipNext = () => {
    if (flipped.includes(current)) return
    setFlipped(prev => [...prev, current])
    setTimeout(() => {
      if (current < drawn.length - 1) setCurrent(prev => prev + 1)
      else setPhase('done')
    }, 600)
  }

  const revealAll = () => { setFlipped(drawn.map((_, i) => i)); setPhase('done') }

  const packKey = Object.keys(PACK_SIZES).find(k => PACK_SIZES[k].cantidad === pack.cantidad) || 'x5'

  return (
    <div style={{ position:'fixed',inset:0,zIndex:200,display:'flex',alignItems:'center',justifyContent:'center',background:'rgba(61,43,90,0.7)',backdropFilter:'blur(6px)',padding:16 }}
      onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{ background:'linear-gradient(160deg,#F3EEFF,#EBF6FD)',borderRadius:24,padding:24,width:'100%',maxWidth:420,maxHeight:'90vh',overflowY:'auto',boxShadow:'0 20px 60px rgba(61,43,90,0.3)',position:'relative' }}>

        <div style={{ display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20 }}>
          <div style={{ fontFamily:"'Pacifico',cursive",fontSize:'1.3rem',color:'#7B5EA7' }}>Pack x{pack.cantidad} 🎁</div>
          <button onClick={onClose} style={{ background:'none',border:'none',fontSize:'1.4rem',cursor:'pointer',color:'#9B80C0',lineHeight:1 }}>✕</button>
        </div>

        {phase === 'intro' && (
          <div style={{ textAlign:'center',padding:'20px 0' }}>
            <div style={{ fontSize:'4rem',marginBottom:12,animation:'bounce 0.8s infinite alternate' }}>🎁</div>
            <div style={{ fontWeight:800,fontSize:'1.1rem',color:'#3D2B5A',marginBottom:8 }}>¡Tu pack está listo!</div>
            <p style={{ color:'#6B4F8A',fontSize:'.9rem',marginBottom:24 }}>Contiene {pack.cantidad} figuritas aleatorias.<br/>¿Listo para abrirlo?</p>
            <button className="btn-pri" onClick={startOpening} style={{ maxWidth:220,margin:'0 auto' }}>¡Abrir pack! 🐾</button>
          </div>
        )}

        {phase === 'opening' && (
          <div style={{ textAlign:'center',padding:'30px 0' }}>
            <div style={{ fontSize:'4rem',animation:'spin 0.4s linear infinite' }}>🎁</div>
            <div style={{ fontWeight:800,color:'#7B5EA7',marginTop:16,fontSize:'1.1rem' }}>Abriendo...</div>
          </div>
        )}

        {(phase === 'reveal' || phase === 'done') && (
          <div>
            <p style={{ textAlign:'center',color:'#6B4F8A',fontSize:'.82rem',marginBottom:16,fontWeight:700 }}>
              {phase === 'reveal' ? `Tocá la figurita ${current + 1} de ${drawn.length} para revelarla` : '¡Estas son tus figuritas!'}
            </p>
            <div style={{ display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:10,marginBottom:20 }}>
              {drawn.map((f, i) => {
                const isFlipped = flipped.includes(i)
                const isActive = i === current && phase === 'reveal'
                const ec = estadoClass(f.estado)
                return (
                  <div key={i} onClick={() => isActive && flipNext()}
                    style={{ perspective:600,cursor:isActive?'pointer':'default',transform:isActive?'scale(1.06)':'scale(1)',transition:'transform .2s' }}>
                    <div style={{ position:'relative',width:'100%',paddingBottom:'140%',transition:'transform 0.5s',transformStyle:'preserve-3d',transform:isFlipped?'rotateY(180deg)':'rotateY(0deg)' }}>
                      {/* BACK */}
                      <div style={{ position:'absolute',inset:0,borderRadius:14,background:isActive?'linear-gradient(135deg,#C9B8E8,#A78FD0)':'linear-gradient(135deg,#E8DFFA,#D5C8F0)',border:`2px solid ${isActive?'#A78FD0':'#C9B8E8'}`,backfaceVisibility:'hidden',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:6,boxShadow:isActive?'0 4px 20px rgba(167,143,208,0.5)':'none' }}>
                        <span style={{ fontSize:'1.8rem' }}>🐾</span>
                        <span style={{ fontSize:'.65rem',fontWeight:800,color:isActive?'#fff':'#9B80C0',textTransform:'uppercase',letterSpacing:'.05em' }}>{isActive?'¡Tocame!':''}</span>
                        {isActive && <span style={{ fontSize:'.6rem',color:'rgba(255,255,255,0.8)' }}>tap tap</span>}
                      </div>
                      {/* FRONT */}
                      <div style={{ position:'absolute',inset:0,borderRadius:14,background:catBg(f.categoria),border:`2px solid ${catBorder(f.categoria)}`,backfaceVisibility:'hidden',transform:'rotateY(180deg)',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'flex-start',gap:4,padding:'6px 4px 8px',overflow:'hidden',boxShadow:f.categoria==='soplitos_pro'?'0 4px 16px rgba(245,200,66,0.35)':'0 3px 12px rgba(167,143,208,0.2)' }}>
                        {FOTOS[f.id] ? (
                          <div style={{ width:'100%',flex:1,borderRadius:9,overflow:'hidden',minHeight:0 }}>
                            <img src={FOTOS[f.id]} alt={f.nombre} style={{ width:'100%',height:'100%',objectFit:'cover',objectPosition:'top' }} />
                          </div>
                        ) : <span style={{ fontSize:'1.6rem',margin:'auto' }}>🐾</span>}
                        <span style={{ fontSize:'.72rem',fontWeight:800,color:'#3D2B5A',textAlign:'center',lineHeight:1.2,width:'100%' }}>{f.nombre}</span>
                        <span style={{ fontSize:'.6rem',color:'#6B4F8A' }}>{f.edad} · {f.sexo}</span>
                        <span className={`fig-est ${ec}`} style={{ fontSize:'.55rem' }}>{f.estado}</span>
                        <span style={{ fontSize:'.55rem',fontWeight:700,color:catBorder(f.categoria),textAlign:'center' }}>{catLabel(f.categoria)}</span>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>

            {phase === 'reveal' && flipped.length < drawn.length && (
              <div style={{ textAlign:'center' }}>
                <button onClick={revealAll} style={{ background:'none',border:'2px solid #C9B8E8',borderRadius:12,padding:'8px 20px',color:'#7B5EA7',fontFamily:"'Nunito',sans-serif",fontWeight:700,fontSize:'.85rem',cursor:'pointer' }}>
                  Revelar todas
                </button>
              </div>
            )}

            {phase === 'done' && (
              <div style={{ textAlign:'center',marginTop:4 }}>
                <div style={{ fontSize:'1.5rem',marginBottom:8 }}>🎉</div>
                <p style={{ color:'#6B4F8A',fontSize:'.82rem',marginBottom:16 }}>¿Te gustó la simulación?<br/>Comprá tu pack real y ayudá al refugio 💜</p>
                <div style={{ display:'flex',gap:10,justifyContent:'center',flexWrap:'wrap' }}>
                  <a href={PACK_SIZES[packKey].link} target="_blank" rel="noopener noreferrer" className="btn-pack"
                    style={{ display:'inline-block',padding:'10px 20px',borderRadius:12,fontSize:'.88rem' }}>
                    Comprar pack real 🛍️
                  </a>
                  <button onClick={onClose} style={{ background:'none',border:'2px solid #C9B8E8',borderRadius:12,padding:'10px 20px',color:'#7B5EA7',fontFamily:"'Nunito',sans-serif",fontWeight:700,fontSize:'.88rem',cursor:'pointer' }}>
                    Cerrar
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
