import { useState } from 'react'
import { PACK_SIZES } from '../data/figuritas'
import PackOpenModal from './PackOpenModal'

export default function TiendaSection() {
  const [openPack, setOpenPack] = useState(null)

  return (
    <div>
      <h1 className="sec-title">Tienda</h1>
      <p className="sec-sub">Cada compra va 100% al refugio 🐾</p>

      <div className="info-card" style={{ marginBottom: 20 }}>
        <div className="ititle">💜 Tu compra ayuda de verdad</div>
        <p>El 100% de cada pago va directamente a la cuenta del refugio Soplo de Vida para comprar alimento, medicación, cubrir gastos veterinarios y más.</p>
      </div>

      <div style={{ fontWeight:800,color:'#3D2B5A',fontSize:'.88rem',marginBottom:10,textTransform:'uppercase',letterSpacing:'.04em' }}>
        🎁 Elegí tu pack
      </div>
      <div className="pack-grid" style={{ marginBottom: 8 }}>
        {Object.entries(PACK_SIZES).map(([k, p]) => (
          <div key={k} className="pack-card">
            <div className="pack-emoji">🎁</div>
            <div className="pack-name">Pack x{p.cantidad}</div>
            <div className="pack-price">${p.precio}</div>
            <button className="btn-pack" onClick={() => setOpenPack(p)}>Simular apertura</button>
            <a href={p.link} target="_blank" rel="noopener noreferrer"
              style={{ display:'block',textAlign:'center',fontSize:'.78rem',color:'#7B5EA7',fontWeight:700,textDecoration:'underline' }}>
              Comprar real →
            </a>
          </div>
        ))}
      </div>
      <p style={{ fontSize:'.78rem',color:'#9B80C0',textAlign:'center',marginBottom:24 }}>
        La simulación es solo para ver cómo funcionan los packs. Para coleccionar de verdad, ¡comprá el pack real!
      </p>

      <div className="don-card">
        <div className="don-title">💙 Donaciones</div>
        <p style={{ fontSize:'.88rem',color:'#6B4F8A',marginBottom:10 }}>
          Toda ayuda sirve. Podés donar el monto que quieras:{' '}
          <a href="https://link.mercadopago.com.ar/soplodevida" target="_blank" rel="noopener noreferrer" style={{ color:'#7B5EA7',fontWeight:700 }}>Donar ahora 🐾</a>
        </p>
        <p style={{ fontSize:'.85rem',color:'#6B4F8A',marginBottom:8 }}>
          También nos ayuda mucho si querés hacer donaciones en especie. Escribinos a nuestro Instagram para coordinar, necesitamos:
        </p>
        <ul className="don-list">
          <li>Alimento de perro y de gato (adulto y cachorro)</li>
          <li>Pipetas y antiparasitarios</li>
          <li>Medicación veterinaria</li>
          <li>Mantas, toallas, camitas</li>
          <li>Piedritas sanitarias para gato</li>
          <li>Leche maternizada (consultarnos marcas)</li>
          <li>Insumos farmacéuticos: vendas, alcohol, gasas, etc.</li>
        </ul>
        <a href="https://www.instagram.com/soplodevida_/" target="_blank" rel="noopener noreferrer"
          style={{ display:'inline-flex',alignItems:'center',gap:6,marginTop:8,background:'linear-gradient(135deg,#C9B8E8,#A78FD0)',color:'#fff',borderRadius:10,padding:'8px 16px',textDecoration:'none',fontWeight:800,fontSize:'.85rem' }}>
          📲 Instagram Soplo de Vida
        </a>
      </div>

      {openPack && <PackOpenModal pack={openPack} onClose={() => setOpenPack(null)} />}
    </div>
  )
}
