import { useState } from 'react'
import { FIGURITAS_DATA } from '../data/figuritas'

export default function CambiosSection({ userData, allUsers, onUpdate, showToast }) {
  const owned = new Set(userData?.album || [])
  const [ofrezco, setOfrezco] = useState('')
  const [busco, setBusco] = useState('')

  const allCambios = allUsers
    .filter(u => u.username !== userData.username)
    .flatMap(u => (u.cambios || []).map(c => ({ ...c, fromUser: u.username })))

  const figById = id => FIGURITAS_DATA.find(f => f.id === id)

  const handlePublish = () => {
    if (!ofrezco || !busco) return
    const nc = { id: Date.now(), ofrezco: parseInt(ofrezco), busco: parseInt(busco) }
    onUpdate({ ...userData, cambios: [...(userData.cambios || []), nc] })
    setOfrezco(''); setBusco('')
    showToast('¡Cambio publicado! 🔄')
  }

  const opO = FIGURITAS_DATA.filter(f => owned.has(f.id))
  const opB = FIGURITAS_DATA.filter(f => !owned.has(f.id))

  return (
    <div>
      <h1 className="sec-title">Cambios</h1>
      <p className="sec-sub">Intercambiá tus repetidas con otros coleccionistas</p>

      <div className="cambio-form">
        <div style={{ fontWeight:800,color:'#3D2B5A',marginBottom:14,fontSize:'.9rem' }}>Publicar un cambio</div>
        <label className="ilbl">Ofrezco</label>
        <select value={ofrezco} onChange={e => setOfrezco(e.target.value)}>
          <option value="">— Figurita que tenés —</option>
          {opO.map(f => <option key={f.id} value={f.id}>#{f.id} {f.nombre} ({f.sexo})</option>)}
        </select>
        <label className="ilbl">Busco</label>
        <select value={busco} onChange={e => setBusco(e.target.value)}>
          <option value="">— Figurita que te falta —</option>
          {opB.map(f => <option key={f.id} value={f.id}>#{f.id} {f.nombre} ({f.sexo})</option>)}
        </select>
        <button className="btn-pri" onClick={handlePublish} style={{ marginTop: 4 }}>Publicar cambio</button>
      </div>

      <div style={{ fontWeight:800,color:'#3D2B5A',marginBottom:10 }}>Cambios de otros usuarios</div>
      {allCambios.length === 0 ? (
        <div className="empty"><div className="eemoji">🔄</div><p>Todavía no hay cambios publicados.<br/>¡Sé el primero!</p></div>
      ) : allCambios.map(c => {
        const fo = figById(c.ofrezco), fb = figById(c.busco)
        const puedo = owned.has(c.busco) && !owned.has(c.ofrezco)
        return (
          <div key={c.id} className="cambio-card">
            <div className="cambio-user">@{c.fromUser} ofrece:</div>
            <div className="cambio-row">
              <span>{fo?.nombre}</span><span className="cambio-arrow">→</span><span>busca: {fb?.nombre}</span>
            </div>
            {puedo && (
              <button className="btn-acc" onClick={() => showToast(`¡Cambio aceptado con ${c.fromUser}! Coordinen por mensaje 💬`)}>
                ✅ ¡Me sirve este cambio!
              </button>
            )}
          </div>
        )
      })}

      {(userData.cambios || []).length > 0 && (
        <div style={{ marginTop: 20 }}>
          <div style={{ fontWeight:800,color:'#3D2B5A',marginBottom:10 }}>Mis cambios publicados</div>
          {userData.cambios.map(c => {
            const fo = figById(c.ofrezco), fb = figById(c.busco)
            return (
              <div key={c.id} className="cambio-card" style={{ borderColor:'#D5C8F0' }}>
                <div className="cambio-row">
                  <span>{fo?.nombre}</span><span className="cambio-arrow">→</span><span>busco: {fb?.nombre}</span>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
