import { VOLUNTARIADOS } from '../data/figuritas'

export default function ComunidadSection() {
  return (
    <div>
      <h1 className="sec-title">Comunidad</h1>
      <p className="sec-sub">Sumate al voluntariado de Soplo de Vida 🐾</p>
      {VOLUNTARIADOS.map((v, i) => (
        <div key={i} className="vol-card">
          <div className="vol-name">{v.nombre}</div>
          <div className="vol-desc">{v.descripcion}</div>
          <a href={v.link} target="_blank" rel="noopener noreferrer" className="btn-wa">
            💬 Unirme al grupo
          </a>
        </div>
      ))}
    </div>
  )
}
