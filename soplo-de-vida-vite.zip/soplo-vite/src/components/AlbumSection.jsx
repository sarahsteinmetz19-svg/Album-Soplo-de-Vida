import { useState } from 'react'
import { FIGURITAS_DATA, estadoClass, getPct } from '../data/figuritas'
import { FOTOS } from '../data/fotos'

export default function AlbumSection({ userData }) {
  const owned = new Set(userData?.album || [])
  const total = FIGURITAS_DATA.length
  const pct = getPct(owned.size, total)
  const [filtro, setFiltro] = useState('todas')

  const cats = [
    { key: 'soplitos',     label: 'Soplitos' },
    { key: 'soplitos_pro', label: 'Soplitos Pro ⭐' },
    { key: 'angelitos',    label: 'Angelitos 🕊️' },
  ]

  const applyFilter = (figs) => {
    if (filtro === 'tengo')     return figs.filter(f => owned.has(f.id))
    if (filtro === 'me-faltan') return figs.filter(f => !owned.has(f.id))
    return figs
  }

  const adoptFigs = FIGURITAS_DATA.filter(f => f.estado === 'En adopción' && owned.has(f.id))

  const filterBtns = [
    { key: 'todas',     label: 'Todas',      count: total },
    { key: 'tengo',     label: 'Las tengo',  count: owned.size },
    { key: 'me-faltan', label: 'Me faltan',  count: total - owned.size },
  ]

  return (
    <div>
      <h1 className="sec-title">Mi Álbum</h1>
      <p className="sec-sub">{owned.size} de {total} figuritas</p>
      <div className="prog-lbl"><span>Completado</span><span>{pct}%</span></div>
      <div className="prog-wrap"><div className="prog-fill" style={{ width: `${pct}%` }} /></div>

      {/* Filter buttons */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
        {filterBtns.map(btn => (
          <button key={btn.key} onClick={() => setFiltro(btn.key)} style={{
            flex: 1, minWidth: 90, padding: '9px 12px', border: 'none', borderRadius: 12, cursor: 'pointer',
            fontFamily: "'Nunito', sans-serif", fontWeight: 800, fontSize: '.82rem', transition: 'all .15s',
            background: filtro === btn.key ? 'linear-gradient(135deg,#C9B8E8,#A78FD0)' : '#fff',
            color: filtro === btn.key ? '#fff' : '#6B4F8A',
            boxShadow: filtro === btn.key ? '0 3px 12px rgba(167,143,208,.4)' : '0 1px 6px rgba(167,143,208,.15)',
            outline: filtro === btn.key ? 'none' : '2px solid #E8DFFA',
          }}>
            {btn.label}
            <span style={{
              display: 'inline-block', marginLeft: 6,
              background: filtro === btn.key ? 'rgba(255,255,255,.25)' : '#E8DFFA',
              color: filtro === btn.key ? '#fff' : '#9B80C0',
              borderRadius: 20, padding: '1px 7px', fontSize: '.72rem', fontWeight: 700,
            }}>{btn.count}</span>
          </button>
        ))}
      </div>

      {cats.map(cat => {
        const figs = applyFilter(FIGURITAS_DATA.filter(f => f.categoria === cat.key))
        if (figs.length === 0) return null
        return (
          <div key={cat.key}>
            <div className="cat-hdr">
              <span className={`cat-badge ${cat.key}`}>{cat.label}</span>
              <div className="cat-line" />
            </div>
            <div className="fig-grid">
              {figs.map(f => {
                const isOwned = owned.has(f.id)
                const ec = estadoClass(f.estado)
                const foto = FOTOS[f.id]
                return (
                  <div key={f.id} className={`fig ${cat.key} ${isOwned ? 'owned' : 'not-owned'}`}>
                    <span className="fig-num">#{f.id}</span>
                    {foto ? (
                      <div style={{
                        width: '100%', height: 80, borderRadius: 10, overflow: 'hidden', marginBottom: 2,
                        filter: isOwned ? 'none' : 'grayscale(1) brightness(0.85)',
                      }}>
                        <img src={foto} alt={f.nombre} style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'top' }} />
                      </div>
                    ) : (
                      <span style={{ fontSize: '1.8rem' }}>🐾</span>
                    )}
                    <span className="fig-name">{f.nombre}</span>
                    <span className="fig-det">{f.edad} · {f.sexo}</span>
                    <span className={`fig-est ${ec}`}>{f.estado}</span>
                    {f.pareja && <span className="fig-pareja">💑 con {f.pareja}</span>}
                  </div>
                )
              })}
            </div>
          </div>
        )
      })}

      {filtro === 'todas' && adoptFigs.length > 0 && (
        <div className="ig-card" style={{ marginTop: 20 }}>
          <strong>¿Querés adoptar?</strong> Si querés que alguno de estos soplitos sea parte de tu familia,{' '}
          <a href="https://www.instagram.com/soplodevida_/" target="_blank" rel="noopener noreferrer">
            escribinos por Instagram 🐾
          </a>
        </div>
      )}
    </div>
  )
}
