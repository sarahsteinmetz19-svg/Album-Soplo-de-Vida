import { useState, useEffect } from 'react'
import './styles/global.css'
import AuthScreen from './components/AuthScreen'
import AlbumSection from './components/AlbumSection'
import TiendaSection from './components/TiendaSection'
import CambiosSection from './components/CambiosSection'
import RankingSection from './components/RankingSection'
import ComunidadSection from './components/ComunidadSection'

const NAV_ITEMS = [
  { key: 'album',     icon: '📖', label: 'Mi Álbum' },
  { key: 'tienda',    icon: '🛍️', label: 'Tienda' },
  { key: 'cambios',   icon: '🔄', label: 'Cambios' },
  { key: 'ranking',   icon: '🏆', label: 'Ranking' },
  { key: 'comunidad', icon: '💜', label: 'Comunidad' },
]

export default function App() {
  const [users, setUsers] = useState({})
  const [currentUser, setCurrentUser] = useState(null)
  const [tab, setTab] = useState('album')
  const [toast, setToast] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    try { const r = localStorage.getItem('sdv_users'); if (r) setUsers(JSON.parse(r)) } catch {}
    try { const r = localStorage.getItem('sdv_session'); if (r) setCurrentUser(r) } catch {}
    setLoading(false)
  }, [])

  const saveUsers = (nu) => { setUsers(nu); localStorage.setItem('sdv_users', JSON.stringify(nu)) }
  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(''), 3000) }
  const handleLogin = (username, nu) => { setUsers(nu); setCurrentUser(username) }
  const handleLogout = () => { localStorage.removeItem('sdv_session'); setCurrentUser(null) }
  const updateUserData = (nd) => { const nu = { ...users, [nd.username]: nd }; saveUsers(nu) }

  if (loading) return (
    <div style={{ minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',background:'linear-gradient(160deg,#D6EEFA,#E8DFFA)' }}>
      <div style={{ textAlign:'center' }}>
        <div style={{ fontSize:'3rem' }}>🐾</div>
        <div style={{ fontWeight:700,color:'#7B5EA7',marginTop:10 }}>Cargando...</div>
      </div>
    </div>
  )

  if (!currentUser) return <AuthScreen onLogin={handleLogin} />

  const userData = users[currentUser] || { username: currentUser, album: [], cambios: [] }
  const allUsersArr = Object.values(users)

  return (
    <div className="app">
      {toast && <div className="toast">{toast}</div>}

      <header className="hdr">
        <div className="hdr-logo">🐾 Soplo de Vida</div>
        <div className="hdr-usr">
          <div className="avatar">{currentUser[0].toUpperCase()}</div>
          <div className="uname">@{currentUser}</div>
          <button className="btn-out" onClick={handleLogout}>Salir</button>
        </div>
      </header>

      <main className="main">
        {tab === 'album'     && <AlbumSection    userData={userData} />}
        {tab === 'tienda'    && <TiendaSection />}
        {tab === 'cambios'   && <CambiosSection  userData={userData} allUsers={allUsersArr} onUpdate={updateUserData} showToast={showToast} />}
        {tab === 'ranking'   && <RankingSection  allUsers={allUsersArr} />}
        {tab === 'comunidad' && <ComunidadSection />}
      </main>

      <nav className="nav">
        {NAV_ITEMS.map(item => (
          <button key={item.key} className={`nitem ${tab === item.key ? 'active' : ''}`} onClick={() => setTab(item.key)}>
            <span className="nico">{item.icon}</span>
            <span className="nlbl">{item.label}</span>
          </button>
        ))}
      </nav>
    </div>
  )
}
