# 🐾 Álbum Soplo de Vida

Álbum de figuritas virtual del refugio Soplo de Vida.

## Estructura del proyecto

```
soplo-de-vida/
├── index.html
├── vite.config.js
├── package.json
├── src/
│   ├── main.jsx               ← entrada
│   ├── App.jsx                ← app principal
│   ├── styles/
│   │   └── global.css
│   ├── data/
│   │   ├── figuritas.js       ← datos de los 89 animales
│   │   └── fotos.js           ← fotos en base64
│   └── components/
│       ├── AuthScreen.jsx
│       ├── AlbumSection.jsx
│       ├── TiendaSection.jsx
│       ├── PackOpenModal.jsx
│       ├── CambiosSection.jsx
│       ├── RankingSection.jsx
│       └── ComunidadSection.jsx
```

## Correr localmente

```bash
npm install
npm run dev
```

## Deploy en Vercel

1. Subí esta carpeta a un repositorio de GitHub
2. Entrá a [vercel.com](https://vercel.com) → **Add New Project**
3. Importá el repo → Vercel detecta Vite automáticamente
4. Click **Deploy** → en 2 minutos tenés la URL pública ✅

## Deploy manual (build)

```bash
npm run build
# Los archivos quedan en /dist, listos para cualquier hosting estático
```
